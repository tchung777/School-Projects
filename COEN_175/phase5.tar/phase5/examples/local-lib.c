/*
 * This file will not be run through your compiler.
 */

void print(int a, int b, int c)
{
    printf("%d %d %d\n", a, b, c);
}
