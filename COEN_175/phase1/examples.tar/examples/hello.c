/* hello.c */

int printf(char *s, ...);

int main(void)
{
    printf("Hello, world.%c", '\n');
}
