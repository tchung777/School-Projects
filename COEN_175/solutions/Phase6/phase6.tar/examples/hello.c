/* hello.c */

int main(void)
{
    printf("hello world\n");
}
